# Integer-Java-Virtual-Machine
An IJVM emulator - VU Amsterdam PAD course
